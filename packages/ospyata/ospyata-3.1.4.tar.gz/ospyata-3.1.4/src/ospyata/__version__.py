# Copyright (c) 2021-present aerocyber
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

__version__ = '3.1.4'
__spec_version__ = '3.0.0'
