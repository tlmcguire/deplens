# Copyright (c) 2021-present aerocyber
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

from . import osmata as o, __version__ as v

__version__ = v.__version__
__spec_version__ =v.__spec_version__
